var scores = 0;

$(function(){
    var win_h = $(window).height();
    var win_w = $(window).width();

    
    $(".container").css("min-height",win_h+"px");
    $(".container_result").css("min-height",win_h+"px");

    $(".result_bg").css("height",win_h+"px");
    $(".modal_share").css("height",win_h+"px");
    // $(".result_bg").css("width",win_w+"px");
    // 
})

function down(self,classname){
    $(self).css("margin-top","42px");
    $(self).addClass(classname);  
}
function move(self,classname){
    $(self).css("margin-top","30px");
    $(self).removeClass(classname);
}

function up(self,classname,fa,to){
    $(self).css("margin-top","30px");
    $(self).removeClass(classname);
    if(fa=="3") //第三个问题
    {
        //结果统计
        var temp_chose= $(self).attr("data-num");
        $.ajax({
            url: '',
            type: '',
            dataType: 'get',
            data: {chose: temp_chose},
        })

        //计算结果
        $(".container_3").hide();
        $(".result_egg").append('<img src="http://static.qiezipai.cn/activity/qixi/image/result/waiting.gif" class="result_wait">');      
        $(".container_result").show();
        window.setTimeout(function(){
        $(".result_wait").css("display","none");
        if( scores<5){
            $(".result3").css("display","block");
            var temp_title=$(".result3").attr("data-value");
            shareTitle = "在异地恋中我最需要的是“"+temp_title+"”，你的呢？"
        }else if( 5<=scores<=8){
            $(".result2").css("display","block");
            var temp_title=$(".result3").attr("data-value");
            shareTitle = "在异地恋中我最需要的是“"+temp_title+"”，你的呢？"
        }else if(scores>8){
            $(".result1").css("display","block");
            var temp_title=$(".result3").attr("data-value");
            shareTitle = "在异地恋中我最需要的是“"+temp_title+"”，你的呢？"
        }
    },4500);
    }else if(fa=="4"){
        // 结果页分享
        modal_show();
    }else if(fa=="5"){
        // 结果页下载
    }else
    {   
        var temp_num = $(self).attr("data-num");
        scores = parseInt(scores) + parseInt(temp_num);
        $(".container_"+fa+"").hide();
        $("."+to+"").show();
    }
}

function modal_show(){
    $(".modal_share").css("left","0");
    $(".share_guide").css("left","0");
    window.setTimeout(function(){
    $(".modal_share").on("click",function(){
        $(".modal_share").css("left","-640px");
        $(".share_guide").css("left","-640px");

        $(".modal_share").off("click");//注销
    });
    },500);
}