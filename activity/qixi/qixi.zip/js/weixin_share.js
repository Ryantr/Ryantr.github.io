

var appid=$("#appid").val();
var timestamp=$("#timestamp").val();
var nonceStr=$("#nonceStr").val();
var signature=$("#signature").val();


var imgUrl = 'http://www.qiezipai.cn/image_m/logo_m.png';  // 分享后展示的一张图片
var lineLink = $("#shareUrl").val(); // 点击分享后跳转的页面地址
var descContent = "茄子拍送我20个大红包，分你一个！茄子拍，一款用心提供青春摄影服务的App";  // 分享后的描述信息
var shareTitle = '在异地恋中我最需要的是“”，你的呢？';  // 分享后的标题

wx.config({
    debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
    appId: appid, // 必填，公众号的唯一标识
    timestamp:timestamp, // 必填，生成签名的时间戳
    nonceStr: nonceStr, // 必填，生成签名的随机串
    signature: signature,// 必填，签名，见附录1
    jsApiList: ['onMenuShareTimeline','onMenuShareAppMessage',''] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
});


wx.ready(function(){
    
    wx.onMenuShareAppMessage({
        title: shareTitle, // 分享标题
        desc: descContent, // 分享描述
        link: lineLink, // 分享链接
        imgUrl: imgUrl, // 分享图标
        type: 'link', // 分享类型,music、video或link，不填默认为link
        dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
    });  

    wx.onMenuShareTimeline({
        title: shareTitle, // 分享标题
        link: lineLink, // 分享链接
        imgUrl: imgUrl, // 分享图标
    });

});
/*
wx.error(function(res){

    alert(res);

});
*/
